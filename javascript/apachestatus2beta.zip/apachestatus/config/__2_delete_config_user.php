<?php
/*
 * PIMPED APACHE-STATUS
 * 
 * TEMPLATE FOR USER CONFIG FILE
 * 
 * !!! COPY THIS FILE TO "config_user.php" to make your setup !!!
 * set values in config_default.php to override default settings
 * 
 * http://www.axel-hahn.de/docs/apachestatus/custom.htm
 */

$aServergroups = array(

    'my default environment' => array(
        'servers' => array(
            'localhost' => array(
                'label' => 'localhost',
                // 'status-url' => 'http://username:password@localhost:80/server-status',
            ),
        ),
    ),
    'multitest' => array(
        'servers' => array(
            'localhost 1' => array(
                'label' => 'localhost 1',
                'status-url' => 'http://localhost/server-status',
            ),
            'localhost 2' => array(
                'label' => 'localhost 2',
                'status-url' => 'http://localhost/server-status',
            ),
            'localhost 3' => array(
                'label' => 'localhost 3',
                'status-url' => 'http://localhost/server-status',
            ),
            'localhost 4' => array(
                'label' => 'localhost 4',
                'status-url' => 'http://localhost/server-status',
            ),
            'localhost 5' => array(
                'label' => 'localhost 5',
                'status-url' => 'http://localhost/server-status',
            ),
            'localhost 6' => array(
                'label' => 'localhost 6',
                'status-url' => 'http://localhost/server-status',
            ),
            'localhost 7' => array(
                'label' => 'localhost 7',
                'status-url' => 'http://localhost/server-status',
            ),
            'localhost 8' => array(
                'label' => 'localhost 8',
                'status-url' => 'http://localhost/server-status',
            ),
            'localhost 9' => array(
                'label' => 'localhost 9',
                'status-url' => 'http://localhost/server-status',
            ),
            'localhost 10' => array(
                'label' => 'localhost 10',
                'status-url' => 'http://localhost/server-status',
            ),
            'localhost 11' => array(
                'label' => 'localhost 11',
                'status-url' => 'http://localhost/server-status',
            ),
            'localhost 12' => array(
                'label' => 'localhost 12',
                'status-url' => 'http://localhost/server-status',
            ),
            'localhost 13' => array(
                'label' => 'localhost 13',
                'status-url' => 'http://localhost/server-status',
            ),
            'localhost 14' => array(
                'label' => 'localhost 14',
                'status-url' => 'http://localhost/server-status',
            ),
            'localhost 15' => array(
                'label' => 'localhost 15',
                'status-url' => 'http://localhost/server-status',
            ),
        ),
    ),
    'my clustered web 1' => array(
        'servers' => array(
            'server1' => array(),
            'server2' => array(),
            'server3' => array(),
        ),
    ),
    'my clustered web 2' => array(
        'servers' => array(
            'www.apache.org' => array(),
            'serverA' => array(),
            'serverB' => array(),
            'serverC' => array(),
            'serverD' => array(),
        ),
    ),
  
    /*
    // example for a loadbalanced web
    // default server-status is
    // http://[servername]/server-status
    // use "server-status" to fetch apache server status from another url or port
    'my clustered web 1' => array(
        'servers' => array(
            'webserver-01' => array(
                'label' => 's01',
                'status-url' => 'http://s01:8888/server-status',
            ),
            'webserver-02' => array(
                'label' => 's02',
                'status-url' => 'http://s02:8888/server-status',
            ),
        ),
    ),
     */
 
);



$aUserCfg = array(
    // 'lang' => 'en', // one of de|en
    'auth' => array(
        'user'=>'axel',
        'password'=>md5('axel'), 
    ),
    'tdlink' => array(
        'Client' => array('href'=>'http://whatismyipaddress.com/ip/%s', 'target'=>'_blank', 'title'=>'lookup IP %s'),
    ),
    // 'tdbars' => array('Count', 'Anzahl'),
    // ich will einmal so schreiben:
    // 'tdbars' => array('thCount'),
    
    // 'tdbars' => array('Count', 'Req', 'Child', 'Slot'),

    // 'showHint' => false,
    // 'hideRows' => array("Srv", "Acc", "Conn", "Child", "Slot"),
    /*
    'skin' => 'default', // where to search style.css and defaultTemplate
     */
	// 'selectSkin' => 'default,ice,summer',
);

?>
