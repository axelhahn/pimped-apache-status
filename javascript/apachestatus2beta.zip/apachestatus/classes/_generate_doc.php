<?php

require_once("d:\htdocs\axel-hahn.de\local\axel\php\classinfos.class.php");
foreach (array(
            "datarenderer"=>"Datarenderer",
            "page"=>"Page",
            "primitivelogger"=>"PrimitiveLogger",
            "serverstatus"=>"ServerStatus",
    ) as $sFile=>$sClassname){

            $docfile=dirname(__FILE__).'\..\docs\simpledoc_'.$sFile.'.html';
            // require_once("../classinfos/classinfos.class.php");
            require_once("$sFile.class.php");
            $o=new classinfos($sClassname);

            $s=$o->render("html");
            echo $docfile."\n";
            file_put_contents($docfile, $s);
    }
