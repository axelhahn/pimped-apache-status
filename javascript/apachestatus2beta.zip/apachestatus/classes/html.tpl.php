<!doctype html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        
        <meta name="robots" content="noindex, nofollow" />
        <script src="{{APPDIR}}/javascript/functions.js" type="text/javascript"></script>
        <script src="{{APPDIR}}/javascript/counterhistory.class.js" type="text/javascript"></script>
        <script src="{{APPDIR}}/javascript/datatables/media/js/jquery.js" type="text/javascript"></script>
        <script src="{{APPDIR}}/javascript/datatables/media/js/jquery.dataTables.min.js" type="text/javascript"></script>
        <title>Pimped Apache Status</title>

        {{HEADER}}

    </head><body>

        {{CONTENT}}

        {{FOOTER}}{{JSONREADY}}
    </body>
</html>